import React, { Component } from 'react';

// Parent Component
class BlankSpace extends Component {
  render() {
    return(
      <div>
        <a href="http://google.com">Google</a>{" "}
        <a href="http://facebook.com">Facebook</a>
      </div>
    )
  }
}

export default BlankSpace
