import React, { Component } from 'react';

// Parent Component
class Comments extends Component {
  render() {
    return(
      <div>
        {/* put {} around comments */}
        <span>This component has comments</span>
      </div>
    )
  }
}

export default Comments
