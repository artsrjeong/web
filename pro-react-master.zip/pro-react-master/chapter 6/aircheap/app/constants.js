export default {
  FETCH_AIRPORTS: 'fetch airports',
  FETCH_AIRPORTS_SUCCESS: 'fetch airports success',
  FETCH_AIRPORTS_ERROR: 'fetch airports error',
  CHOOSE_AIRPORT: 'choose airport',
  FETCH_TICKETS: 'fetch tickets',
  FETCH_TICKETS_SUCCESS: 'fetch tickets success',
  FETCH_TICKETS_ERROR: 'fetch tickets error'
};
